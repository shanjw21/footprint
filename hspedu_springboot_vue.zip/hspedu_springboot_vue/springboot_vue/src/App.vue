<template>
  <div>
<!--    引用组件 头部-->
    <Header/>
<!--    主体-->
    <div style="display:flex">
<!--      侧边栏-->
      <Aside/>
<!--      内容区域, 这个部分是从HomeView.vue组件的来的(通过路由机制)-->
        <router-view style="flex: 1"/>
    </div>
  </div>
</template>
<style>
</style>
<script>
// 老师提示这里的基础知识在前端技术栈-es6 , 如果忘了，自己回顾
  import Header from "@/components/Header";
  import Aside from "@/components/Aside";
  export default {
    name: "Layout",
    components: {
      Header,
      Aside
    }
  }
</script>