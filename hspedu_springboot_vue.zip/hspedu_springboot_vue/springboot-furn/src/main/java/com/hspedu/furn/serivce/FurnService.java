package com.hspedu.furn.serivce;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hspedu.furn.bean.Furn;

/**
 * @author 韩顺平
 * @version 1.0
 *
 */
public interface FurnService extends IService<Furn> {
    //如果有其它的需求，可以在该接口声明方法，然后再对应的实现类进行实现
    //在前面我们讲解springboot 整合 mybatis-plus讲过
}
