package com.hspedu.furn.service;

import com.hspedu.furn.bean.Furn;

import java.util.List;

/**
 * @author 韩顺平
 * @version 1.0
 */
public interface FurnService {
    //添加
    public void save(Furn furn);
    //查询所有的家居信息
    public List<Furn> findAll();
    //修改家居
    public void update(Furn furn);
    //删除家居
    public void del(Integer id);

    //根据id返回Furn
    public Furn findById(Integer id);

    //根据家居名称进行查询
    public List<Furn> findByCondition(String name);
}
